import sqlite3
import os
from flask import Flask, render_template, request, url_for, flash, redirect, abort, session, send_file
from datetime import datetime
from ReportCreator import ReportGenerator
from MailSender import EmailSender
from GetConfigFile import returnData
import json


class GuiFlaskSite:
    def __init__(self):
        self.app = Flask(__name__)
        self.data = returnData()

        # Set the secret key
        self.app.config['SECRET_KEY'] = os.urandom(24).hex()

        # Function to establish a connection to the SQLite database
        def get_db_connection():
            conn = sqlite3.connect('database.db')
            conn.row_factory = sqlite3.Row
            return conn

        # Function to retrieve a single post from the database
        def get_post(post_id):
            conn = get_db_connection()
            post = conn.execute('SELECT * FROM posts WHERE id = ?', (post_id,)).fetchone()
            conn.close()
            if post is None:
                abort(404)
            return post

        # Function to retrieve key_stroke records for a specific date and ID
        def get_records_by_date_and_id(id, date):
            conn = sqlite3.connect('database.db')
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("SELECT url FROM posts WHERE id = ?", (id,))
            row = cursor.fetchone()
            conn.close()

            if row is not None:
                records_folder = get_post(id)[5]
                folder_path = os.path.join(records_folder, date)
                if os.path.exists(folder_path):
                    files = os.listdir(folder_path)
                    file_paths = [os.path.join(folder_path, file) for file in files]
                    return file_paths
            return []

        @self.app.route('/login', methods=['GET', 'POST'])
        def login():
            if request.method == 'POST':
                username = request.form['username']
                password = request.form['password']
                if username == self.data['UserName'] and password == self.data['Password']:
                    session['logged_in'] = True
                    return redirect(url_for('index'))
                else:
                    flash('Invalid username or password!')
                    return render_template('login.html')

            # If the user is already logged in, redirect to the index page
            if session.get('logged_in'):
                return redirect(url_for('index'))

            return render_template('login.html')

        # Route for the index page
        @self.app.route('/')
        def index():
            if not session.get('logged_in'):
                flash('Access Denied!')
                return redirect(url_for('login'))
            else:
                conn = get_db_connection()
                posts = conn.execute('SELECT * FROM posts').fetchall()
                conn.close()
                return render_template('index.html', posts=posts)

        # Logout route
        @self.app.route('/logout')
        def logout():
            session['logged_in'] = False
            return redirect(url_for('login'))

        @self.app.route('/change-details', methods=['GET', 'POST'])
        def change_details():
            if not session.get('logged_in'):
                flash('Access Denied!')
                return redirect(url_for('login'))

            if request.method == 'POST':
                new_username = request.form['new_username']
                new_password = request.form['new_password']
                new_email = request.form['new_email']
                msg_to_flush = ' changed successfully.'
                what_changed = ''
                counter = 0

                # Update the username and/or password in the data dictionary
                if new_email:
                    self.data['EmailAddress'] = new_email
                    what_changed = 'email, ' + what_changed
                    counter += 1
                if new_password:
                    self.data['Password'] = new_password
                    what_changed = 'password, ' + what_changed
                    counter += 1
                if new_username:
                    self.data['UserName'] = new_username
                    what_changed = 'user name, ' + what_changed
                    counter += 1

                # Write the updated data back to the Config.json file
                with open("Config.json", "w") as jsonfile:
                    json.dump(self.data, jsonfile)
                    print("Write successful")

                if counter == 1:
                    msg_to_flush = ' was' + msg_to_flush
                else:
                    msg_to_flush = ' were' + msg_to_flush

                what_changed = what_changed[:-2]
                flash('The ' + what_changed + msg_to_flush)
                return redirect(url_for('index'))

            return render_template('change_details.html')

        # Create route
        @self.app.route('/create/', methods=('GET', 'POST'))
        def create():
            if not session.get('logged_in'):
                flash('Access Denied!')
                return redirect(url_for('login'))

            if request.method == 'POST':
                url = request.form['url']
                content = request.form['content']
                status = int(
                    request.form.get('status', 0))  # Retrieve the status value as an integer (0 if not checked)

                if not url:
                    flash('URL is required!')
                elif not content:
                    flash('Content is required!')
                else:
                    conn = get_db_connection()
                    query = 'INSERT INTO posts (url, content, status) VALUES (?, ?, ?)'
                    conn.execute(query, (url, content, status))
                    conn.commit()
                    conn.close()

                    flash(f'The {url} rule was successfully created!')
                    return redirect(url_for('index'))

            return render_template('create.html')

        # Edit route
        @self.app.route('/<int:id>/edit/', methods=('GET', 'POST'))
        def edit(id):
            if not session.get('logged_in'):
                flash('Access Denied!')
                return redirect(url_for('login'))

            post = get_post(id)

            if request.method == 'POST':
                url = request.form['url']
                content = request.form['content']
                status = int(
                    request.form.get('status', 0))  # Retrieve the status value as an integer (0 if not checked)

                if not url:
                    flash('URL is required!')
                elif not content:
                    flash('Content is required!')
                else:
                    conn = get_db_connection()
                    query = 'UPDATE posts SET url = ?, content = ?, status = ? WHERE id = ?'
                    conn.execute(query, (url, content, status, id))
                    conn.commit()
                    conn.close()
                    return redirect(url_for('index'))

            return render_template('edit.html', post=post)

        # Delete route
        @self.app.route('/<int:id>/delete/', methods=('POST',))
        def delete(id):
            if not session.get('logged_in'):
                return redirect(url_for('login'))
            post = get_post(id)
            conn = get_db_connection()
            conn.execute('DELETE FROM posts WHERE id = ?', (id,))
            conn.commit()
            conn.close()
            flash('"{}" was successfully deleted!'.format(post['url']))
            return redirect(url_for('index'))

        # Watch route
        @self.app.route('/<int:id>/watch/', methods=['GET', 'POST'])
        def watch(id):
            if not session.get('logged_in'):
                return redirect(url_for('login'))

            post = get_post(id)

            if request.method == 'POST':
                selected_date = request.form['selected_date']
                if not selected_date:
                    flash('Please select a date.')
                else:
                    return redirect(url_for('view_records', date=selected_date, id=id))

            return render_template('watch.html', post=post)

        @self.app.route('/view_records/<date>/<int:id>')
        def view_records(date, id):
            if not session.get('logged_in'):
                return redirect(url_for('login'))

            try:
                datetime.strptime(date, '%Y-%m-%d')  # Validate date format
                records = get_records_by_date_and_id(id, date)
                post = get_post(id)  # Retrieve the post object based on the id
                return render_template('view_records.html', date=date, records=records, post=post, id=id)
            except ValueError:
                abort(404)

        # Route for downloading a file
        @self.app.route('/download/<int:id>/<path:filename>')
        def download_file(id, filename):
            if not session.get('logged_in'):
                return redirect(url_for('login'))
            records_folder = os.path.join(get_post(id)[5], filename)
            file_path = os.path.join(records_folder)
            if os.path.exists(file_path):
                return send_file(file_path, as_attachment=True)
            else:
                abort(404)

        @self.app.route('/delete/<int:id>/<filename>', methods=['POST', 'DELETE'])
        def delete_record(id, filename):
            if not session.get('logged_in'):
                return redirect(url_for('login'))
            records_folder = os.path.join(get_post(id)[5], filename)
            file_path = os.path.join(records_folder)
            folder_path = os.path.dirname(file_path)

            if os.path.exists(file_path):
                os.remove(file_path)
                flash('The record was successfully deleted!')

                # Check if the folder is empty after deleting the record
                if not os.listdir(folder_path):
                    os.rmdir(folder_path)
                    flash('The folder was deleted as it became empty.')

            else:
                flash('Record not found!')

            return redirect(request.referrer)

        @self.app.route('/send-report/', methods=['GET', 'POST'])
        def send_report():
            if not session.get('logged_in'):
                return redirect(url_for('login'))

            if request.method == 'POST':
                selected_date = request.form['selected_date']
                if not selected_date:
                    flash('Please select a date.')
                else:
                    rpt = ReportGenerator()
                    rpt.create_report(selected_date)
                    data = returnData()
                    email = EmailSender()
                    email.send_report_to_email(data["EmailAddress"], selected_date)
                    flash('Report created and sent successfully.')
                    return redirect(url_for('sent'))

            return render_template('sent.html')

        @self.app.route('/sent/')
        def sent():
            if not session.get('logged_in'):
                return redirect(url_for('login'))

            return render_template('sent.html')

    def run(self):
        self.app.run(port=5080)


if __name__ == '__main__':
    g = GuiFlaskSite()
    g.run()
