import sqlite3


class URLChecker:
    def __init__(self):
        self.conn = sqlite3.connect('database.db')
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.execute("SELECT id, created, url, content, status FROM posts")
        self.url_dict = {}  # Dictionary to store ID as key and URL as value

        for row in self.cursor:
            if row['status'] == 1:
                self.url_dict[row['id']] = row['url']

        self.conn.close()

    def check_exists(self, urls):
        converted_urls = ', '.join(str(item) for item in urls)
        for key, val in self.url_dict.items():
            if val in converted_urls:
                return key
        return -1
