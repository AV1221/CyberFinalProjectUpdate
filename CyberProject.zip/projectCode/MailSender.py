import os
import smtplib
import ssl
from email.message import EmailMessage
import GetConfigFile


class EmailSender:
    def __init__(self):
        self.sender_email = "cyberproject41@gmail.com"
        self.email_password = (GetConfigFile.returnData())['EmailPassword']

    def send_report_to_email(self, recipient_email, date):
        subject = "Report"
        body = f"Here is a report for the date: {date}"

        msg = EmailMessage()
        msg["From"] = "Supervision Hub"
        msg["To"] = recipient_email
        msg["Subject"] = subject
        msg.set_content(body)

        rpt_path = f'{os.getcwd()}\\reports\\Records_{date}.pdf'
        with open(rpt_path, "rb") as file:
            report_data = file.read()

        msg.add_attachment(report_data, maintype="application", subtype="pdf", filename=f"Records_{date}.pdf")

        context = ssl.create_default_context()

        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as smtp:
            smtp.login(self.sender_email, self.email_password)
            smtp.send_message(msg)
            print("Email sent successfully!")
